# Android chat tutorial: Building A Realtime Messaging App

These are the project files for the [Scaledrone Android chat tutorial](https://www.scaledrone.com/blog/posts/android-chat-tutorial).

To run this example make sure to replace the `channelID` in [`MainActivity.java`](https://github.com/ScaleDrone/android-chat-tutorial/blob/master/app/src/main/java/com/example/scaledrone/chat/MainActivity.java)
